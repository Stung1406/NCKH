﻿# Countdown Solver â€” Reinforcement Learning (MCTS + Q-Learning)

> **NghiÃªn cá»©u khoa há»c** | Giáº£i bÃ i toÃ¡n Countdown báº±ng phÆ°Æ¡ng phÃ¡p Há»c tÄƒng cÆ°á»ng

---

## Má»¥c lá»¥c

1. [Tá»•ng quan dá»± Ã¡n](#1-tá»•ng-quan-dá»±-Ã¡n)
2. [BÃ i toÃ¡n Countdown lÃ  gÃ¬?](#2-bÃ i-toÃ¡n-countdown-lÃ -gÃ¬)
3. [HÆ°á»›ng Ä‘i vÃ  lÃ½ do chá»n Reinforcement Learning](#3-hÆ°á»›ng-Ä‘i-vÃ -lÃ½-do-chá»n-reinforcement-learning)
4. [LÃ½ thuyáº¿t ná»n táº£ng](#4-lÃ½-thuyáº¿t-ná»n-táº£ng)
5. [Táº¡i sao RL? So sÃ¡nh vá»›i cÃ¡c thuáº­t toÃ¡n khÃ¡c](#5-táº¡i-sao-rl-so-sÃ¡nh-vá»›i-cÃ¡c-thuáº­t-toÃ¡n-khÃ¡c)
6. [MÃ´ hÃ¬nh hÃ³a bÃ i toÃ¡n Countdown dÆ°á»›i dáº¡ng MDP](#6-mÃ´-hÃ¬nh-hÃ³a-bÃ i-toÃ¡n-countdown-dÆ°á»›i-dáº¡ng-mdp)
7. [Kiáº¿n trÃºc há»‡ thá»‘ng](#7-kiáº¿n-trÃºc-há»‡-thá»‘ng)
8. [MÃ´ táº£ chi tiáº¿t tá»«ng file](#8-mÃ´-táº£-chi-tiáº¿t-tá»«ng-file)
9. [CÃ¡c thÆ° viá»‡n Ä‘Æ°á»£c sá»­ dá»¥ng](#9-cÃ¡c-thÆ°-viá»‡n-Ä‘Æ°á»£c-sá»­-dá»¥ng)
10. [CÃ i Ä‘áº·t vÃ  cháº¡y chÆ°Æ¡ng trÃ¬nh](#10-cÃ i-Ä‘áº·t-vÃ -cháº¡y-chÆ°Æ¡ng-trÃ¬nh)
11. [VÃ­ dá»¥ Ä‘áº§u ra](#11-vÃ­-dá»¥-Ä‘áº§u-ra)

---

## 1. Tá»•ng quan dá»± Ã¡n

ÄÃ¢y lÃ  dá»± Ã¡n nghiÃªn cá»©u khoa há»c á»©ng dá»¥ng **Há»c tÄƒng cÆ°á»ng (Reinforcement Learning â€” RL)** Ä‘á»ƒ giáº£i bÃ i toÃ¡n trÃ² chÆ¡i sá»‘ há»c **Countdown**. Dá»± Ã¡n triá»ƒn khai vÃ  so sÃ¡nh hai thuáº­t toÃ¡n RL:

| Thuáº­t toÃ¡n | PhÃ¢n loáº¡i | Äáº·c trÆ°ng |
|---|---|---|
| **Q-Learning** | Model-Free TD Learning | Há»c báº£ng Q tá»« tráº£i nghiá»‡m (episode), lÆ°u Ä‘Æ°á»£c Q-table, Ä‘Ã¡nh giÃ¡ tá»•ng quÃ¡t hÃ³a |
| **MCTS + PUCT** | Model-Based Planning | XÃ¢y cÃ¢y tÃ¬m kiáº¿m cÃ³ hÆ°á»›ng dáº«n báº±ng heuristic prior, khÃ´ng há»c qua nhiá»u láº§n cháº¡y |

Má»¥c tiÃªu há»c thuáº­t cá»§a dá»± Ã¡n:
- MÃ´ hÃ¬nh hÃ³a bÃ i toÃ¡n Countdown thÃ nh **MDP chuáº©n** vá»›i khÃ´ng gian tráº¡ng thÃ¡i, hÃ nh Ä‘á»™ng, hÃ m pháº§n thÆ°á»Ÿng xÃ¡c Ä‘á»‹nh rÃµ rÃ ng.
- Huáº¥n luyá»‡n agent **Q-Learning Ä‘a instance**: agent há»c tá»« nhiá»u bÃ i toÃ¡n khÃ¡c nhau, lÆ°u láº¡i Q-table vÃ  Ä‘Ã¡nh giÃ¡ **kháº£ nÄƒng tá»•ng quÃ¡t hÃ³a** trÃªn táº­p held-out (chÆ°a tháº¥y khi train).
- So sÃ¡nh hiá»‡u nÄƒng giá»¯a **tÃ¬m kiáº¿m heuristic (MCTS)** vÃ  **há»c tÄƒng cÆ°á»ng tháº­t sá»± (Q-Learning)**.
- Trá»±c quan hÃ³a cÃ¢y tÃ¬m kiáº¿m RL qua **Graphviz DOT** vÃ  **giao diá»‡n tÆ°Æ¡ng tÃ¡c Matplotlib**.

---

## 2. BÃ i toÃ¡n Countdown lÃ  gÃ¬?

**Countdown** lÃ  trÃ² chÆ¡i sá»‘ há»c ná»•i tiáº¿ng tá»« chÆ°Æ¡ng trÃ¬nh truyá»n hÃ¬nh Anh. Luáº­t chÆ¡i:

1. Cho trÆ°á»›c má»™t táº­p sá»‘ nguyÃªn dÆ°Æ¡ng (thÆ°á»ng tá»« 2 Ä‘áº¿n 8 sá»‘), vÃ­ dá»¥: `25 50 3 6 7 8`.
2. CÃ³ má»™t **Target** (sá»‘ Ä‘Ã­ch), vÃ­ dá»¥: `952`.
3. NgÆ°á»i chÆ¡i láº§n lÆ°á»£t chá»n **hai sá»‘** báº¥t ká»³ Ä‘ang cÃ³, káº¿t há»£p báº±ng má»™t trong bá»‘n phÃ©p tÃ­nh `+`, `-`, `Ã—`, `Ã·` (vá»›i rÃ ng buá»™c: phÃ©p trá»« cho káº¿t quáº£ dÆ°Æ¡ng, phÃ©p chia pháº£i chia háº¿t).
4. Káº¿t quáº£ thay tháº¿ hai sá»‘ Ä‘Ã³. Tiáº¿p tá»¥c cho Ä‘áº¿n khi chá»‰ cÃ²n má»™t sá»‘.
5. **Luáº­t dá»± Ã¡n**: pháº£i **dÃ¹ng háº¿t táº¥t cáº£** cÃ¡c sá»‘ ban Ä‘áº§u (sá»‘ cÃ²n láº¡i cuá»‘i cÃ¹ng pháº£i báº±ng Target).

**VÃ­ dá»¥ lá»i giáº£i** cho bá»™ sá»‘ `25 50 3 6 7 8`, Target `952`:

```
BÆ°á»›c 1: 25 âˆ’ 6 = 19
BÆ°á»›c 2: 3 + 7 = 10
BÆ°á»›c 3: 19 Ã— 50 = 950
BÆ°á»›c 4: 10 âˆ’ 8 = 2
BÆ°á»›c 5: 2 + 950 = 952
```

---

## 3. HÆ°á»›ng Ä‘i vÃ  lÃ½ do chá»n Reinforcement Learning

### Táº¡i sao khÃ´ng dÃ¹ng thuáº­t toÃ¡n tÃ¬m kiáº¿m truyá»n thá»‘ng?

BÃ i toÃ¡n Countdown cÃ³ thá»ƒ Ä‘Æ°á»£c giáº£i báº±ng nhiá»u cÃ¡ch:

| PhÆ°Æ¡ng phÃ¡p | MÃ´ táº£ | Háº¡n cháº¿ |
|---|---|---|
| **BFS / DFS thuáº§n** | Duyá»‡t toÃ n bá»™ khÃ´ng gian tráº¡ng thÃ¡i | BÃ¹ng ná»• tá»• há»£p: vá»›i 6 sá»‘, cÃ³ hÃ ng nghÃ¬n chuá»—i hÃ nh Ä‘á»™ng cÃ³ thá»ƒ |
| **A\* / Best-First Search** | DÃ¹ng hÃ m heuristic Ä‘á»ƒ Æ°u tiÃªn nhÃ¡nh há»©a háº¹n | Cáº§n thiáº¿t káº¿ heuristic tá»‘t thá»§ cÃ´ng; khÃ´ng tá»± cáº£i thiá»‡n |
| **Backtracking + Pruning** | Cáº¯t nhÃ¡nh sá»›m theo rÃ ng buá»™c | Giáº£i nhanh 1 puzzle nhÆ°ng khÃ´ng há»c Ä‘Æ°á»£c gÃ¬ tá»« nhiá»u puzzle |
| **Reinforcement Learning** | Agent há»c tá»« tráº£i nghiá»‡m thá»­-vÃ -sai | CÃ³ kháº£ nÄƒng tá»•ng quÃ¡t hÃ³a, tá»± cáº£i thiá»‡n chÃ­nh sÃ¡ch qua thá»i gian |

### LÃ½ do chá»n Reinforcement Learning

1. **BÃ i toÃ¡n cÃ³ cáº¥u trÃºc MDP tá»± nhiÃªn**: Má»—i tráº¡ng thÃ¡i lÃ  táº­p sá»‘ hiá»‡n cÃ³, hÃ nh Ä‘á»™ng lÃ  phÃ©p tÃ­nh, pháº§n thÆ°á»Ÿng rÃµ rÃ ng khi Ä‘áº¡t Target. ÄÃ¢y lÃ  MDP xÃ¡c Ä‘á»‹nh (deterministic MDP) Ä‘iá»ƒn hÃ¬nh.

2. **Kháº£ nÄƒng tá»•ng quÃ¡t hÃ³a**: Khi Q-table Ä‘Æ°á»£c huáº¥n luyá»‡n trÃªn nhiá»u bÃ i toÃ¡n (vá»›i state `(numbers, target)`), agent cÃ³ thá»ƒ Ã¡p dá»¥ng kiáº¿n thá»©c Ä‘Ã£ há»c cho cÃ¡c puzzle chÆ°a gáº·p.

3. **NghiÃªn cá»©u há»c thuáº­t**: RL cho phÃ©p Ä‘o lÆ°á»ng **quÃ¡ trÃ¬nh há»c** (learning curve, Q-value convergence, generalization rate) thay vÃ¬ chá»‰ Ä‘Æ°a ra Ä‘Ã¡p Ã¡n â€” Ä‘iá»u mÃ  cÃ¡c thuáº­t toÃ¡n search thuáº§n khÃ´ng lÃ m Ä‘Æ°á»£c.

4. **Linh hoáº¡t vá»›i reward signal**: CÃ³ thá»ƒ thiáº¿t káº¿ reward shaping Ä‘á»ƒ hÆ°á»›ng dáº«n agent táº­p trung vÃ o cÃ¡c bÆ°á»›c tÃ­nh toÃ¡n cÃ³ Ã½ nghÄ©a (nhÆ° Æ°u tiÃªn Æ°á»›c sá»‘ cá»§a Target).

5. **So sÃ¡nh hai paradigm RL**: Dá»± Ã¡n cá»‘ tÃ¬nh cÃ i Ä‘áº·t cáº£ **Model-Free RL** (Q-Learning) vÃ  **Model-Based Planning** (MCTS) Ä‘á»ƒ so sÃ¡nh trá»±c tiáº¿p trong cÃ¹ng mÃ´i trÆ°á»ng.

---

## 4. LÃ½ thuyáº¿t ná»n táº£ng

### 4.1 Markov Decision Process (MDP)

ToÃ n bá»™ bÃ i toÃ¡n Ä‘Æ°á»£c mÃ´ hÃ¬nh hÃ³a dÆ°á»›i dáº¡ng **MDP** â€” bá»™ 5 thÃ nh pháº§n `(S, A, P, R, Î³)`:

| ThÃ nh pháº§n | KÃ½ hiá»‡u | Äá»‹nh nghÄ©a trong Countdown |
|---|---|---|
| **KhÃ´ng gian tráº¡ng thÃ¡i** | S | Tuple sá»‘ nguyÃªn dÆ°Æ¡ng Ä‘Æ°á»£c sáº¯p xáº¿p tÄƒng dáº§n, vÃ­ dá»¥ `(3, 6, 7, 8, 25, 50)` |
| **KhÃ´ng gian hÃ nh Ä‘á»™ng** | A(s) | Táº­p há»£p cÃ¡c phÃ©p tÃ­nh há»£p lá»‡ `(left, op, right, result, next_state)` táº¡i tráº¡ng thÃ¡i s |
| **HÃ m chuyá»ƒn tráº¡ng thÃ¡i** | P(s'\|s,a) | XÃ¡c Ä‘á»‹nh (deterministic): má»—i hÃ nh Ä‘á»™ng cho Ä‘Ãºng má»™t tráº¡ng thÃ¡i káº¿ tiáº¿p |
| **HÃ m pháº§n thÆ°á»Ÿng** | R(s, a, s') | +100 khi thÃ nh cÃ´ng, âˆ’10 khi tháº¥t báº¡i, shaping reward cho cÃ¡c bÆ°á»›c trung gian |
| **Há»‡ sá»‘ chiáº¿t kháº¥u** | Î³ = 0.95 | Æ¯u tiÃªn pháº§n thÆ°á»Ÿng ngáº¯n háº¡n hÆ¡n dÃ i háº¡n |

**TÃ­nh cháº¥t Markov**: Tráº¡ng thÃ¡i hiá»‡n táº¡i `s` chá»©a Ä‘á»§ thÃ´ng tin Ä‘á»ƒ quyáº¿t Ä‘á»‹nh hÃ nh Ä‘á»™ng tá»‘i Æ°u â€” khÃ´ng cáº§n biáº¿t lá»‹ch sá»­ cÃ¡c bÆ°á»›c trÆ°á»›c. Vá»›i Q-Learning Ä‘a instance, Target Ä‘Æ°á»£c Ä‘Æ°a vÃ o khÃ³a Q-table: `(state, target, action)`, Ä‘áº£m báº£o tÃ­nh Markov Ä‘áº§y Ä‘á»§.

### 4.2 Q-Learning â€” Temporal Difference Learning

**Q-Learning** lÃ  thuáº­t toÃ¡n **Model-Free TD Learning** â€” agent khÃ´ng cáº§n biáº¿t mÃ´ hÃ¬nh mÃ´i trÆ°á»ng (hÃ m P vÃ  R) mÃ  há»c trá»±c tiáº¿p tá»« tráº£i nghiá»‡m.

**HÃ m giÃ¡ trá»‹ hÃ nh Ä‘á»™ng Q(s, a)** Æ°á»›c lÆ°á»£ng tá»•ng pháº§n thÆ°á»Ÿng chiáº¿t kháº¥u ká»³ vá»ng khi thá»±c hiá»‡n hÃ nh Ä‘á»™ng `a` táº¡i tráº¡ng thÃ¡i `s` vÃ  sau Ä‘Ã³ theo chÃ­nh sÃ¡ch tá»‘i Æ°u:

```
Q(s, a) â† Q(s, a) + Î± Ã— [r + Î³ Ã— max_{a'} Q(s', a') âˆ’ Q(s, a)]
```

Trong Ä‘Ã³:
- `Î± = 0.25` â€” **learning rate**: kiá»ƒm soÃ¡t tá»‘c Ä‘á»™ cáº­p nháº­t
- `Î³ = 0.95` â€” **discount factor**: chiáº¿t kháº¥u pháº§n thÆ°á»Ÿng tÆ°Æ¡ng lai
- `r + Î³ Ã— max Q(s', a')` â€” **TD target**: Æ°á»›c lÆ°á»£ng giÃ¡ trá»‹ thá»±c theo phÆ°Æ¡ng trÃ¬nh Bellman
- `r + Î³ Ã— max Q(s', a') âˆ’ Q(s, a)` â€” **TD error**: pháº§n sai sá»‘ cáº§n sá»­a

**QuÃ¡ trÃ¬nh há»c** qua cÃ¡c episode:
1. Reset vá» tráº¡ng thÃ¡i ban Ä‘áº§u.
2. Chá»n hÃ nh Ä‘á»™ng theo **epsilon-greedy** (thÄƒm dÃ² vs. khai thÃ¡c).
3. Thá»±c hiá»‡n hÃ nh Ä‘á»™ng, nháº­n `(s', r, done)`.
4. Cáº­p nháº­t Q theo cÃ´ng thá»©c Bellman.
5. Láº·p Ä‘áº¿n khi káº¿t thÃºc episode, rá»“i báº¯t Ä‘áº§u episode má»›i.

**Q-table** trong dá»± Ã¡n: lÆ°u dáº¡ng `dict` Python vá»›i khÃ³a `(state_tuple, target, action_key)` â†’ giÃ¡ trá»‹ Q. CÃ³ thá»ƒ serialize ra JSON Ä‘á»ƒ lÆ°u/náº¡p giá»¯a cÃ¡c láº§n cháº¡y.

### 4.3 Monte Carlo Tree Search (MCTS) + PUCT

**MCTS** lÃ  ká»¹ thuáº­t **láº­p káº¿ hoáº¡ch cÃ³ hÆ°á»›ng dáº«n** (guided planning) xÃ¢y dá»±ng cÃ¢y quyáº¿t Ä‘á»‹nh báº±ng bá»‘n pha:

```
1. SELECTION       â†’ Äi tá»« gá»‘c xuá»‘ng lÃ¡ theo cÃ´ng thá»©c PUCT
2. EXPANSION       â†’ Má»Ÿ rá»™ng node lÃ¡, thÃªm node con má»›i
3. ROLLOUT         â†’ MÃ´ phá»ng ngáº«u nhiÃªn cÃ³ hÆ°á»›ng Ä‘áº¿n terminal state
4. BACKPROPAGATION â†’ Cáº­p nháº­t N(s,a) vÃ  Q(s,a) ngÆ°á»£c tá»« lÃ¡ vá» gá»‘c
```

**CÃ´ng thá»©c PUCT** (Predictor Upper Confidence Trees â€” dÃ¹ng trong AlphaZero):

```
PUCT(s, a) = Q(s, a) + c_puct Ã— P(s, a) Ã— sqrt(N(s)) / (1 + N(s, a))
```

Trong Ä‘Ã³:
- `Q(s, a)` â€” **GiÃ¡ trá»‹ khai thÃ¡c** (exploitation): giÃ¡ trá»‹ trung bÃ¬nh cá»§a hÃ nh Ä‘á»™ng
- `P(s, a)` â€” **Policy prior** (tiÃªn nghiá»‡m chÃ­nh sÃ¡ch): xÃ¡c suáº¥t Æ°u tiÃªn hÃ nh Ä‘á»™ng dá»±a trÃªn heuristic
- `N(s)` â€” Sá»‘ láº§n node cha Ä‘Æ°á»£c ghÃ© thÄƒm
- `N(s, a)` â€” Sá»‘ láº§n hÃ nh Ä‘á»™ng `a` Ä‘Æ°á»£c thá»±c hiá»‡n tá»« `s`
- `c_puct = 2.0` â€” Háº±ng sá»‘ cÃ¢n báº±ng khai thÃ¡c-thÄƒm dÃ²

**Policy Prior `P(s, a)`** trong dá»± Ã¡n (heuristic, khÃ´ng Ä‘Æ°á»£c há»c tá»« neural network):

```
score = âˆ’|result âˆ’ Target| / Target + 5 Ã— [result lÃ  Æ°á»›c cá»§a Target]
P(s, a) = softmax(score)
```

**Rollout strategy**: 70% chá»n hÃ nh Ä‘á»™ng cÃ³ káº¿t quáº£ gáº§n Target nháº¥t; 30% chá»n ngáº«u nhiÃªn. DÃ¹ng chiáº¿t kháº¥u `Î³ = 0.95` theo Ä‘á»™ sÃ¢u rollout.

**Multi-Restart**: Khi cÃ¢y tÃ¬m kiáº¿m rÆ¡i vÃ o dead-end (táº¥t cáº£ nhÃ¡nh Ä‘Ã£ duyá»‡t, khÃ´ng tÃ¬m Ä‘Æ°á»£c lá»i giáº£i), tá»± Ä‘á»™ng khá»Ÿi láº¡i cÃ¢y má»›i â€” tá»‘i Ä‘a 10 láº§n restart Ã— 3000 simulations/restart.

> **LÆ°u Ã½**: MCTS trong dá»± Ã¡n dÃ¹ng heuristic prior cá»‘ Ä‘á»‹nh, **khÃ´ng** cÃ³ policy/value neural network. ÄÃ¢y lÃ  MCTS heuristic, khÃ´ng pháº£i AlphaZero tháº­t sá»±.

### 4.4 Reward Shaping

**Reward Shaping** lÃ  ká»¹ thuáº­t thiáº¿t káº¿ hÃ m pháº§n thÆ°á»Ÿng phá»¥ Ä‘á»ƒ hÆ°á»›ng dáº«n agent há»c nhanh hÆ¡n, bá»• sung cho pháº§n thÆ°á»Ÿng terminal thÆ°a (sparse reward):

**Pháº§n thÆ°á»Ÿng terminal:**
- ThÃ nh cÃ´ng (sá»‘ cÃ²n láº¡i = Target): `R = +100`
- Tháº¥t báº¡i (sá»‘ cÃ²n láº¡i â‰  Target): `R = âˆ’10 âˆ’ |sá»‘_cuá»‘i âˆ’ Target| / 100`

**Reward shaping cho cÃ¡c bÆ°á»›c trung gian:**

```
r(s, a, s') = âˆ’0.1 + 10 Ã— (d(s) âˆ’ d(s')) / max(1, Target) + 2 Ã— [result lÃ  Æ°á»›c cá»§a Target]

d(s) = min_{x âˆˆ s} |x âˆ’ Target|   (khoáº£ng cÃ¡ch gáº§n nháº¥t tá»›i Target)
```

Ã nghÄ©a tá»«ng thÃ nh pháº§n:
- `âˆ’0.1` â€” Chi phÃ­ bÆ°á»›c Ä‘i, pháº¡t agent náº¿u kÃ©o dÃ i khÃ´ng cáº§n thiáº¿t.
- `10 Ã— (d(s) âˆ’ d(s')) / Target` â€” ThÆ°á»Ÿng tiáº¿n trÃ¬nh: thÆ°á»Ÿng náº¿u tiáº¿p cáº­n Target, pháº¡t náº¿u xa ra.
- `+2` náº¿u result lÃ  Æ°á»›c sá»‘ cá»§a Target â€” Bonus chiáº¿n lÆ°á»£c: Æ°u tiÃªn táº¡o ra cÃ¡c sá»‘ cÃ³ thá»ƒ chia Target sau nÃ y.

### 4.5 Epsilon-Greedy Exploration

Chiáº¿n lÆ°á»£c cÃ¢n báº±ng **exploration** (thÄƒm dÃ², khÃ¡m phÃ¡ hÃ nh Ä‘á»™ng má»›i) vÃ  **exploitation** (khai thÃ¡c, dÃ¹ng hÃ nh Ä‘á»™ng tá»‘t nháº¥t Ä‘Ã£ biáº¿t):

```
Vá»›i xÃ¡c suáº¥t Îµ:    Exploration â€” chá»n hÃ nh Ä‘á»™ng ngáº«u nhiÃªn (cÃ³ hÆ°á»›ng dáº«n)
Vá»›i xÃ¡c suáº¥t 1âˆ’Îµ:  Exploitation â€” chá»n hÃ nh Ä‘á»™ng cÃ³ Q(s,a) cao nháº¥t
```

Trong dá»± Ã¡n, exploration cÃ³ thÃªm **heuristic bias**:
- 60% xÃ¡c suáº¥t trong exploration: chá»n hÃ nh Ä‘á»™ng cÃ³ káº¿t quáº£ gáº§n Target nháº¥t.
- 40% cÃ²n láº¡i: chá»n ngáº«u nhiÃªn thuáº§n.

**Epsilon decay** (giáº£m dáº§n theo episode):
- Epsilon ban Ä‘áº§u: `Îµ = 0.45`
- Giáº£m sau má»—i episode: `Îµ â† max(Îµ_min, Îµ Ã— 0.9997)`
- Epsilon tá»‘i thiá»ƒu: `Îµ_min = 0.1`

â†’ Giai Ä‘oáº¡n Ä‘áº§u: thÄƒm dÃ² nhiá»u â†’ Giai Ä‘oáº¡n sau: khai thÃ¡c chÃ­nh sÃ¡ch Ä‘Ã£ há»c.

---

## 5. Táº¡i sao RL? So sÃ¡nh vá»›i cÃ¡c thuáº­t toÃ¡n khÃ¡c

### Báº£ng so sÃ¡nh tá»•ng quan

| TiÃªu chÃ­ | BFS/DFS | A* Search | Backtracking | MCTS (dá»± Ã¡n) | Q-Learning (dá»± Ã¡n) |
|---|---|---|---|---|---|
| **Äáº£m báº£o tÃ¬m nghiá»‡m** | CÃ³ (náº¿u tá»“n táº¡i) | CÃ³ | CÃ³ | KhÃ´ng (heuristic) | KhÃ´ng (há»c xÃ¡c suáº¥t) |
| **Hiá»‡u quáº£ bá»™ nhá»›** | KÃ©m (BFS lÆ°u toÃ n cÃ¢y) | Trung bÃ¬nh | Tá»‘t | Tá»‘t (giá»›i háº¡n cÃ¢y) | Tá»‘t (Q-table nhá») |
| **Tá»± cáº£i thiá»‡n qua thá»i gian** | KhÃ´ng | KhÃ´ng | KhÃ´ng | KhÃ´ng | **CÃ³** |
| **Tá»•ng quÃ¡t hÃ³a** | KhÃ´ng | KhÃ´ng | KhÃ´ng | KhÃ´ng | **CÃ³** (qua Q-table) |
| **Cáº§n thiáº¿t káº¿ heuristic** | KhÃ´ng | CÃ³ (thá»§ cÃ´ng) | KhÃ´ng | CÃ³ (thá»§ cÃ´ng) | KhÃ´ng (há»c tá»± Ä‘á»™ng) |
| **Äo lÆ°á»ng quÃ¡ trÃ¬nh há»c** | KhÃ´ng | KhÃ´ng | KhÃ´ng | Háº¡n cháº¿ | **CÃ³** (episode, Q-value) |
| **PhÃ¹ há»£p nghiÃªn cá»©u RL** | KhÃ´ng | KhÃ´ng | KhÃ´ng | Háº¡n cháº¿ | **CÃ³** |

### Q-Learning vs. MCTS trong dá»± Ã¡n

| TiÃªu chÃ­ | Q-Learning | MCTS + PUCT |
|---|---|---|
| **PhÃ¢n loáº¡i** | Model-Free RL | Model-Based Planning |
| **Há»c Ä‘Æ°á»£c gÃ¬** | Q(s,a) tá»« nhiá»u episode, lÆ°u Q-table | KhÃ´ng há»c xuyÃªn láº§n cháº¡y |
| **Tá»•ng quÃ¡t hÃ³a** | CÃ³ (state mang theo target) | KhÃ´ng |
| **Tá»‘c Ä‘á»™ giáº£i 1 puzzle** | Cháº­m hÆ¡n (cáº§n nhiá»u episode) | Nhanh hÆ¡n |
| **PhÃ¹ há»£p nghiÃªn cá»©u RL** | **CÃ³** | Baseline so sÃ¡nh |
| **HÆ°á»›ng má»Ÿ rá»™ng** | DQN, Actor-Critic | AlphaZero tháº­t sá»± |

---

## 6. MÃ´ hÃ¬nh hÃ³a bÃ i toÃ¡n Countdown dÆ°á»›i dáº¡ng MDP

```
Tráº¡ng thÃ¡i ban Ä‘áº§u:  sâ‚€ = (3, 6, 7, 8, 25, 50)   [sorted tuple]
Target:              T  = 952

VÃ­ dá»¥ má»™t episode thÃ nh cÃ´ng:

sâ‚€ = (3, 6, 7, 8, 25, 50)
  â†’ hÃ nh Ä‘á»™ng: 25 âˆ’ 6 = 19     r = shaping reward
sâ‚ = (3, 7, 8, 19, 50)
  â†’ hÃ nh Ä‘á»™ng: 3 + 7 = 10      r = shaping reward
sâ‚‚ = (8, 10, 19, 50)
  â†’ hÃ nh Ä‘á»™ng: 19 Ã— 50 = 950   r = shaping reward
sâ‚ƒ = (8, 10, 950)
  â†’ hÃ nh Ä‘á»™ng: 10 âˆ’ 8 = 2      r = shaping reward
sâ‚„ = (2, 950)
  â†’ hÃ nh Ä‘á»™ng: 2 + 950 = 952   r = +100  [DONE, SUCCESS]
sâ‚… = (952,)                    [terminal state]
```

**KhÃ´ng gian tráº¡ng thÃ¡i**: CÃ³ thá»ƒ lÃªn tá»›i hÃ ng chá»¥c nghÃ¬n tráº¡ng thÃ¡i khÃ¡c nhau tÃ¹y bá»™ sá»‘ Ä‘áº§u vÃ o â†’ phÃ¹ há»£p dÃ¹ng Q-table dáº¡ng báº£ng (tabular Q-Learning), khÃ´ng cáº§n xáº¥p xá»‰ hÃ m (function approximation).

**HÃ nh Ä‘á»™ng há»£p lá»‡** táº¡i tráº¡ng thÃ¡i `s` (Ä‘á»‹nh nghÄ©a trong `get_valid_actions`):
- Chá»n má»i cáº·p sá»‘ `(a, b)` phÃ¢n biá»‡t tá»« `s` (theo index, khÃ´ng theo giÃ¡ trá»‹).
- Táº¡o ra táº¥t cáº£ phÃ©p toÃ¡n há»£p lá»‡: `+`, `Ã—`, `aâˆ’b` (náº¿u a > b > 0), `aÃ·b` (náº¿u b|a).
- Lá»c trÃ¹ng láº·p theo káº¿t quáº£ (khÃ´ng táº¡o nhiá»u hÃ nh Ä‘á»™ng cho cÃ¹ng má»™t káº¿t quáº£ tá»« cÃ¹ng má»™t cáº·p).

---

## 7. Kiáº¿n trÃºc há»‡ thá»‘ng

```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚                          main.py                                  â”‚
â”‚    (Äiá»u phá»‘i: Ä‘á»c input, chá»n algo, hiá»ƒn thá»‹, lÆ°u káº¿t quáº£)      â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
           â”‚
     â”Œâ”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”
     â”‚            â”‚
     â–¼            â–¼
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”  â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚countdown â”‚  â”‚                   rl_agent.py                     â”‚
â”‚_env.py   â”‚  â”‚                                                   â”‚
â”‚          â”‚  â”‚  â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”   â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”  â”‚
â”‚ - State  â”‚  â”‚  â”‚  MCTSRLSolver   â”‚   â”‚   QLearningAgent     â”‚  â”‚
â”‚ - Action â”‚  â”‚  â”‚  (MCTS + PUCT)  â”‚   â”‚   (TD Learning)      â”‚  â”‚
â”‚ - Reward â”‚  â”‚  â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜   â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜  â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜  â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
                            â”‚
                            â–¼
                â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
                â”‚  tree_visualizer.py   â”‚
                â”‚  (DOT + PNG export)   â”‚
                â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

**Luá»“ng cháº¡y chÃ­nh (`--mode solve`):**
1. `main.py` Ä‘á»c `input.txt` â†’ láº¥y `numbers` vÃ  `target`.
2. Khá»Ÿi táº¡o `SearchTreeRecorder` Ä‘á»ƒ ghi láº¡i cÃ¢y tÃ¬m kiáº¿m.
3. Gá»i `solve_countdown_rl()` trong `rl_agent.py`.
4. `countdown_env.py` cung cáº¥p mÃ´i trÆ°á»ng MDP cho agent.
5. Agent tráº£ vá» chuá»—i phÃ©p tÃ­nh (operations).
6. `main.py` dá»±ng cÃ¡c bÆ°á»›c chi tiáº¿t, lÆ°u `ketqua.txt`, xuáº¥t `tree.dot`/`tree.png`.
7. Hiá»ƒn thá»‹ giao diá»‡n tÆ°Æ¡ng tÃ¡c Matplotlib (náº¿u khÃ´ng cÃ³ `--no-gui`).

---

## 8. MÃ´ táº£ chi tiáº¿t tá»«ng file

### `countdown_env.py` â€” MÃ´i trÆ°á»ng MDP

**Vai trÃ²**: Äá»‹nh nghÄ©a mÃ´i trÆ°á»ng Markov Decision Process cho bÃ i toÃ¡n Countdown. ÄÃ¢y lÃ  layer "physics" cá»§a há»‡ thá»‘ng â€” xÃ¡c Ä‘á»‹nh cÃ¡ch tráº¡ng thÃ¡i chuyá»ƒn Ä‘á»•i vÃ  pháº§n thÆ°á»Ÿng Ä‘Æ°á»£c tÃ­nh.

**Class chÃ­nh**: `CountdownEnv`

| Method | MÃ´ táº£ |
|---|---|
| `__init__(numbers, target, require_use_all)` | Khá»Ÿi táº¡o mÃ´i trÆ°á»ng vá»›i bá»™ sá»‘, Target vÃ  luáº­t dÃ¹ng háº¿t sá»‘ |
| `reset()` | Äáº·t láº¡i vá» tráº¡ng thÃ¡i ban Ä‘áº§u, tráº£ vá» `sâ‚€` |
| `get_valid_actions(state)` | Liá»‡t kÃª toÃ n bá»™ hÃ nh Ä‘á»™ng há»£p lá»‡ táº¡i tráº¡ng thÃ¡i `state` |
| `step_state(state, action)` | Thá»±c hiá»‡n hÃ nh Ä‘á»™ng trÃªn tráº¡ng thÃ¡i cho trÆ°á»›c, tráº£ vá» `(next_state, reward, done, is_success)` |
| `step(action)` | NhÆ° `step_state` nhÆ°ng cáº­p nháº­t `self.state` ná»™i bá»™ |

**Äiá»ƒm ká»¹ thuáº­t quan trá»ng**:
- Tráº¡ng thÃ¡i lÃ  `tuple` Ä‘Æ°á»£c sáº¯p xáº¿p tÄƒng dáº§n â†’ normalize, trÃ¡nh trÃ¹ng láº·p state.
- Lá»c cáº·p sá»‘ trÃ¹ng láº·p (theo giÃ¡ trá»‹) qua `seen_pairs` Ä‘á»ƒ trÃ¡nh sinh hÃ nh Ä‘á»™ng thá»«a.
- `require_use_all=True` (máº·c Ä‘á»‹nh): káº¿t thÃºc episode chá»‰ khi cÃ²n **1 sá»‘** (pháº£i dÃ¹ng háº¿t).
- `require_use_all=False` (`--allow-partial`): káº¿t thÃºc ngay khi Target xuáº¥t hiá»‡n.

---

### `rl_agent.py` â€” CÃ¡c thuáº­t toÃ¡n RL

**Vai trÃ²**: CÃ i Ä‘áº·t hai thuáº­t toÃ¡n giáº£i quyáº¿t bÃ i toÃ¡n Countdown báº±ng Há»c tÄƒng cÆ°á»ng.

#### Class `MCTSNode`

Node trong cÃ¢y MCTS. LÆ°u trá»¯:
- `state` â€” Tráº¡ng thÃ¡i táº¡i node.
- `prior` â€” Policy prior P(s,a).
- `visits` â€” Sá»‘ láº§n ghÃ© thÄƒm N.
- `total_value` â€” Tá»•ng giÃ¡ trá»‹ nháº­n Ä‘Æ°á»£c.
- `q_value` â€” GiÃ¡ trá»‹ trung bÃ¬nh = total_value / visits.
- `untried_actions` â€” CÃ¡c hÃ nh Ä‘á»™ng chÆ°a thá»­.
- `puct()` â€” TÃ­nh Ä‘iá»ƒm PUCT cho viá»‡c selection.

#### Class `MCTSRLSolver`

| Method | MÃ´ táº£ |
|---|---|
| `__init__(...)` | Khá»Ÿi táº¡o solver vá»›i mÃ´i trÆ°á»ng, sá»‘ restarts, simulations, c_puct |
| `compute_prior(state, action)` | TÃ­nh heuristic score cho hÃ nh Ä‘á»™ng (khoáº£ng cÃ¡ch + bonus Æ°á»›c sá»‘) |
| `_get_actions_with_priors(state)` | Láº¥y danh sÃ¡ch hÃ nh Ä‘á»™ng kÃ¨m prior Ä‘Ã£ softmax hÃ³a |
| `search()` | Thá»±c hiá»‡n MCTS Ä‘a-restart, tráº£ vá» chuá»—i phÃ©p tÃ­nh vÃ  thá»‘ng kÃª |
| `rollout(node)` | MÃ´ phá»ng guided rollout tá»« node, tráº£ vá» giÃ¡ trá»‹ Æ°á»›c lÆ°á»£ng |
| `backpropagate(node, value)` | Cáº­p nháº­t N vÃ  Q tá»« node vá» gá»‘c |
| `extract_path(node)` | TrÃ­ch xuáº¥t chuá»—i phÃ©p tÃ­nh tá»« gá»‘c Ä‘áº¿n node nghiá»‡m |

#### Class `QLearningAgent`

| Method | MÃ´ táº£ |
|---|---|
| `__init__(numbers, target, Î±, Î³, Îµ, ...)` | Khá»Ÿi táº¡o agent vá»›i tham sá»‘ há»c, tÃ¹y chá»n náº¡p Q-table tá»« file |
| `get_q(state, target, action)` | Tra cá»©u Q(s, target, a) khÃ´ng kÃ¨m chÃ¨n khÃ³a trá»‘ng |
| `choose_action(state, target, valid_actions, eps)` | Chá»n hÃ nh Ä‘á»™ng theo epsilon-greedy cÃ³ heuristic bias |
| `train()` | Huáº¥n luyá»‡n trÃªn 1 instance (self.numbers, self.target), tráº£ vá» lá»i giáº£i Ä‘áº§u tiÃªn |
| `train_batch(instances, episodes_per_instance)` | Huáº¥n luyá»‡n trÃªn nhiá»u instance, dÃ¹ng chung Q-table, **khÃ´ng** dá»«ng sá»›m |
| `greedy_success(numbers, target)` | ÄÃ¡nh giÃ¡ policy greedy thuáº§n (khÃ´ng exploration) trÃªn 1 puzzle |
| `save_q_table(path, instances)` | LÆ°u Q-table + metadata ra file JSON |
| `load_q_table(path)` | Náº¡p Q-table tá»« file JSON |

#### HÃ m `generate_solvable_instances`

Sinh ngáº«u nhiÃªn cÃ¡c bÃ i toÃ¡n Countdown **Ä‘áº£m báº£o cÃ³ nghiá»‡m dÃ¹ng háº¿t sá»‘**:
- Láº¥y bá»™ sá»‘ tá»« pool chuáº©n: `[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 25, 50, 75, 100]`.
- Ãp dá»¥ng phÃ©p tÃ­nh ngáº«u nhiÃªn há»£p lá»‡ cho Ä‘áº¿n khi cÃ²n 1 sá»‘ â†’ sá»‘ Ä‘Ã³ lÃ  Target.
- Chá»‰ nháº­n instance cÃ³ Target trong `[100, 999]` vÃ  káº¿t quáº£ trung gian â‰¤ 10000.
- Há»— trá»£ tham sá»‘ `exclude` Ä‘á»ƒ táº¡o táº­p held-out khÃ´ng trÃ¹ng táº­p train.

#### HÃ m `solve_countdown_rl`

Äiá»ƒm vÃ o (entry point) thá»‘ng nháº¥t: nháº­n `algorithm='mcts'` hoáº·c `'qlearning'`, khá»Ÿi táº¡o solver tÆ°Æ¡ng á»©ng vÃ  gá»i `search()` hoáº·c `train()`.

---

### `main.py` â€” Äiá»u phá»‘i chÃ­nh

**Vai trÃ²**: Äiá»ƒm vÃ o chÆ°Æ¡ng trÃ¬nh. Äá»c input, Ä‘iá»u phá»‘i thuáº­t toÃ¡n, hiá»ƒn thá»‹ káº¿t quáº£, quáº£n lÃ½ giao diá»‡n.

**Ba cháº¿ Ä‘á»™ hoáº¡t Ä‘á»™ng** (argument `--mode`):

| Cháº¿ Ä‘á»™ | Lá»‡nh | MÃ´ táº£ |
|---|---|---|
| `solve` | `python main.py` | Giáº£i puzzle trong `input.txt`, xuáº¥t lá»i giáº£i vÃ  giao diá»‡n |
| `train` | `python main.py --mode train` | Huáº¥n luyá»‡n Q-Learning Ä‘a instance, lÆ°u Q-table |
| `eval` | `python main.py --mode eval` | ÄÃ¡nh giÃ¡ tá»•ng quÃ¡t hÃ³a trÃªn puzzle held-out |

**CÃ¡c hÃ m chÃ­nh**:

| HÃ m | MÃ´ táº£ |
|---|---|
| `read_problem(path)` | Äá»c `input.txt`: parse bá»™ sá»‘ vÃ  Target báº±ng regex |
| `countdown_rl(numbers, target, ...)` | Wrapper gá»i `solve_countdown_rl()` |
| `build_steps(numbers, operations)` | Dá»±ng chuá»—i bÆ°á»›c chi tiáº¿t tá»« operations RL, táº¡o biá»ƒu thá»©c toÃ¡n há»c |
| `save_results(...)` | LÆ°u lá»i giáº£i, thá»‘ng kÃª RL vÃ o `ketqua.txt` |
| `save_experiment_report(lines)` | LÆ°u bÃ¡o cÃ¡o train/eval vÃ o `ketqua.txt` |
| `run_train(args)` | Cháº¡y cháº¿ Ä‘á»™ train: sinh instance â†’ huáº¥n luyá»‡n â†’ lÆ°u Q-table |
| `run_eval(args)` | Cháº¡y cháº¿ Ä‘á»™ eval: náº¡p Q-table â†’ Ä‘Ã¡nh giÃ¡ greedy trÃªn held-out |
| `show_simulation(numbers, target, steps, expression)` | Giao diá»‡n tÆ°Æ¡ng tÃ¡c Matplotlib hiá»ƒn thá»‹ tá»«ng bÆ°á»›c |
| `main()` | Parse CLI arguments, Ä‘iá»u phá»‘i toÃ n bá»™ chÆ°Æ¡ng trÃ¬nh |

---

### `tree_visualizer.py` â€” Trá»±c quan hÃ³a cÃ¢y tÃ¬m kiáº¿m

**Vai trÃ²**: Ghi láº¡i vÃ  xuáº¥t cÃ¡c táº§ng Ä‘áº§u cá»§a cÃ¢y tÃ¬m kiáº¿m RL (tá»‘i Ä‘a 2 táº§ng sÃ¢u) ra Ä‘á»‹nh dáº¡ng Graphviz DOT, tÃ¹y chá»n render PNG.

**Class `SearchTreeRecorder`**:

| Method | MÃ´ táº£ |
|---|---|
| `start(state, visits, q_value)` | Táº¡o node gá»‘c (root) cá»§a cÃ¢y |
| `add_transition(parent_id, state, depth, operation, ...)` | ThÃªm cáº¡nh vÃ  node con khi solver duyá»‡t hÃ nh Ä‘á»™ng |
| `finish_node(node_id, succeeded, visits, q_value)` | ÄÃ¡nh dáº¥u káº¿t quáº£ node (SUCCESS/FAILED/SEARCHING) |
| `finish(succeeded, visits, q_value)` | ÄÃ¡nh dáº¥u káº¿t quáº£ node gá»‘c |
| `write_dot(dot_path)` | Xuáº¥t toÃ n bá»™ cÃ¢y thÃ nh file `.dot` (Graphviz format) |
| `render_png(dot_path, png_path)` | Gá»i `dot` binary Ä‘á»ƒ render PNG tá»« file DOT |

**ThÃ´ng tin ghi trong má»—i node DOT**: tráº¡ng thÃ¡i sá»‘, Ä‘á»™ sÃ¢u, N (sá»‘ láº§n ghÃ© thÄƒm), Q (giÃ¡ trá»‹ Q-value), tráº¡ng thÃ¡i (SUCCESS/FAILED/SEARCHING).  
MÃ u sáº¯c: ðŸŸ¢ xanh lÃ¡ = thÃ nh cÃ´ng, ðŸ”´ Ä‘á» = tháº¥t báº¡i, ðŸŸ¡ vÃ ng = Ä‘ang xá»­ lÃ½.

---

### `input.txt` â€” File Ä‘áº§u vÃ o

**Äá»‹nh dáº¡ng**:
```text
25 50 3 6 7 8
Target: 952
```
- DÃ²ng 1: 2â€“8 sá»‘ nguyÃªn dÆ°Æ¡ng cÃ¡ch nhau bá»Ÿi khoáº£ng tráº¯ng.
- DÃ²ng 2: `Target: <sá»‘ Ä‘Ã­ch>`.

---

### `ketqua.txt` â€” File Ä‘áº§u ra

LÆ°u káº¿t quáº£ láº§n cháº¡y gáº§n nháº¥t: thuáº­t toÃ¡n, sá»‘ simulations/episodes, lá»i giáº£i, tá»«ng bÆ°á»›c tÃ­nh, thá»i gian. Bá»‹ ghi Ä‘Ã¨ má»—i láº§n cháº¡y.

---

### `q_table.json` â€” Q-table Ä‘Ã£ há»c

LÆ°u Q-table tá»« cháº¿ Ä‘á»™ `--mode train`. Cáº¥u trÃºc JSON:
```json
{
  "version": 1,
  "rules": {"require_use_all": true},
  "params": {"alpha": 0.25, "gamma": 0.95, "epsilon": 0.45},
  "train_instances": [[[3, 6, 7], 126], ...],
  "entries": [
    {"state": [3, 7, 25], "target": 952, "action": [25, "-", 3, 22], "q": 0.87},
    ...
  ]
}
```

---

### `tree.dot` â€” Graphviz DOT

File Ä‘á»‹nh dáº¡ng DOT chá»©a cÃ¢y tÃ¬m kiáº¿m RL (tá»‘i Ä‘a 2 táº§ng). Má»Ÿ báº±ng Graphviz Viewer hoáº·c render thÃ nh PNG:
```bash
dot -Tpng tree.dot -o tree.png
```

---

## 9. CÃ¡c thÆ° viá»‡n Ä‘Æ°á»£c sá»­ dá»¥ng

### ThÆ° viá»‡n chuáº©n Python (stdlib â€” khÃ´ng cáº§n cÃ i thÃªm)

| ThÆ° viá»‡n | File sá»­ dá»¥ng | Vai trÃ² |
|---|---|---|
| `argparse` | `main.py` | Parse command-line arguments (`--mode`, `--algo`, `--no-gui`, v.v.) |
| `random` | `main.py`, `rl_agent.py` | Sinh sá»‘ ngáº«u nhiÃªn cho epsilon-greedy vÃ  rollout MCTS |
| `re` | `main.py` | Regex parse `input.txt` Ä‘á»ƒ tÃ¡ch bá»™ sá»‘ vÃ  Target |
| `sys` | `main.py` | `sys.exit()` khi lá»—i input; cáº¥u hÃ¬nh encoding UTF-8 cho Windows console |
| `time` | `main.py`, `rl_agent.py` | Äo thá»i gian thá»±c thi báº±ng `time.perf_counter()` |
| `pathlib.Path` | `main.py`, `rl_agent.py`, `tree_visualizer.py` | Quáº£n lÃ½ Ä‘Æ°á»ng dáº«n file cross-platform |
| `json` | `rl_agent.py` | Serialize/deserialize Q-table ra/vÃ o file JSON |
| `math` | `rl_agent.py` | `math.sqrt()` cho PUCT, `math.exp()` cho softmax prior, `math.isclose()` so sÃ¡nh Q-value |
| `collections.defaultdict` | `rl_agent.py` | Q-table dáº¡ng `defaultdict(float)` â€” tá»± tráº£ vá» 0.0 cho khÃ³a chÆ°a cÃ³ |
| `shutil` | `tree_visualizer.py` | `shutil.which("dot")` â€” kiá»ƒm tra Graphviz cÃ³ trong PATH khÃ´ng |
| `subprocess` | `tree_visualizer.py` | Gá»i lá»‡nh `dot -Tpng` Ä‘á»ƒ render cÃ¢y tÃ¬m kiáº¿m ra PNG |
| `typing` | Táº¥t cáº£ file | Type hints: `Tuple`, `List`, `Dict`, `Any`, `Optional` â€” tÄƒng tÃ­nh rÃµ rÃ ng code |

### ThÆ° viá»‡n bÃªn ngoÃ i (cáº§n cÃ i qua pip)

| ThÆ° viá»‡n | File sá»­ dá»¥ng | Vai trÃ² | CÃ i Ä‘áº·t |
|---|---|---|---|
| `matplotlib` | `main.py` | Giao diá»‡n tÆ°Æ¡ng tÃ¡c: váº½ card sá»‘, nÃºt Ä‘iá»u hÆ°á»›ng, hiá»ƒn thá»‹ tá»«ng bÆ°á»›c giáº£i | `pip install matplotlib` |
| `matplotlib.patches.FancyBboxPatch` | `main.py` | Váº½ card sá»‘ bo gÃ³c trong giao diá»‡n simulation | (theo matplotlib) |
| `matplotlib.widgets.Button` | `main.py` | NÃºt "â† TrÆ°á»›c" / "Tiáº¿p â†’" trong giao diá»‡n tÆ°Æ¡ng tÃ¡c | (theo matplotlib) |

### CÃ´ng cá»¥ tÃ¹y chá»n (khÃ´ng pháº£i Python)

| CÃ´ng cá»¥ | Má»¥c Ä‘Ã­ch | Ghi chÃº |
|---|---|---|
| **Graphviz** (`dot`) | Render `tree.dot` â†’ `tree.png` | TÃ¹y chá»n; file `tree.dot` luÃ´n Ä‘Æ°á»£c táº¡o ká»ƒ cáº£ khi chÆ°a cÃ i Graphviz |

---

## 10. CÃ i Ä‘áº·t vÃ  cháº¡y chÆ°Æ¡ng trÃ¬nh

### YÃªu cáº§u

- Python â‰¥ 3.8
- `matplotlib` (báº¯t buá»™c ngay cáº£ khi dÃ¹ng `--no-gui`)
- Graphviz (tÃ¹y chá»n, Ä‘á»ƒ render `tree.png`)

### CÃ i thÆ° viá»‡n

```bash
pip install matplotlib
```

### Äá»‹nh dáº¡ng `input.txt`

```text
25 50 3 6 7 8
Target: 952
```

### CÃ¡c lá»‡nh cháº¡y

```bash
# Giáº£i puzzle báº±ng MCTS (máº·c Ä‘á»‹nh) + má»Ÿ giao diá»‡n
python main.py

# Giáº£i báº±ng Q-Learning + má»Ÿ giao diá»‡n
python main.py --algo qlearning

# Giáº£i MCTS, khÃ´ng má»Ÿ giao diá»‡n
python main.py --no-gui

# Cho phÃ©p dá»«ng sá»›m (khÃ´ng cáº§n dÃ¹ng háº¿t sá»‘)
python main.py --allow-partial

# Huáº¥n luyá»‡n Q-Learning trÃªn 100 instance, 150 episodes/instance
python main.py --mode train --train-instances 100 --episodes-per-instance 150

# ÄÃ¡nh giÃ¡ tá»•ng quÃ¡t hÃ³a trÃªn 50 puzzle held-out
python main.py --mode eval --eval-instances 50

# Huáº¥n luyá»‡n vá»›i seed cá»‘ Ä‘á»‹nh (tÃ¡i hiá»‡n káº¿t quáº£)
python main.py --mode train --seed 42

# Render tree.dot ra tree.png thá»§ cÃ´ng (cáº§n Graphviz)
dot -Tpng tree.dot -o tree.png
```

### Pipeline nghiÃªn cá»©u Ä‘áº§y Ä‘á»§

```bash
# BÆ°á»›c 1: Huáº¥n luyá»‡n
python main.py --mode train --train-instances 200 --episodes-per-instance 200 --seed 42

# BÆ°á»›c 2: ÄÃ¡nh giÃ¡ tá»•ng quÃ¡t hÃ³a
python main.py --mode eval --eval-instances 100 --eval-seed 99

# BÆ°á»›c 3: Giáº£i puzzle cá»¥ thá»ƒ báº±ng Q-table Ä‘Ã£ há»c
python main.py --algo qlearning --no-gui
```

---

## 11. VÃ­ dá»¥ Ä‘áº§u ra

### Cháº¿ Ä‘á»™ `solve` (MCTS)

```text
=== COUNTDOWN â€” REINFORCEMENT LEARNING ===
CÃ¡c sá»‘: 25 50 3 6 7 8
Target: 952
Thuáº­t toÃ¡n: MCTS-RL (Monte Carlo Tree Search + PUCT)
Sá»‘ lÆ°á»£t mÃ´ phá»ng (Simulations): 669
Root Visits: 669 | Root Q-Value: -27.57
Lá»i giáº£i: (((3 + 7) - 8) + ((25 - 6) Ã— 50)) = 952
BÆ°á»›c 1: 25 âˆ’ 6 = 19
BÆ°á»›c 2: 3 + 7 = 10
BÆ°á»›c 3: 19 Ã— 50 = 950
BÆ°á»›c 4: 10 âˆ’ 8 = 2
BÆ°á»›c 5: 2 + 950 = 952
Thá»i gian tÃ¬m kiáº¿m: 59.005 ms
```

### Cháº¿ Ä‘á»™ `train` (Q-Learning)

```text
Sá»‘ instance huáº¥n luyá»‡n: 100
Episodes má»—i instance: 150
Tá»•ng sá»‘ episodes: 15000
Epsilon cuá»‘i: 0.1013
Sá»‘ instance tá»«ng Ä‘Æ°á»£c giáº£i khi train: 87/100
Sá»‘ má»¥c Q-table: 43821
Thá»i gian huáº¥n luyá»‡n: 3241.7 ms
```

### Cháº¿ Ä‘á»™ `eval` (ÄÃ¡nh giÃ¡ tá»•ng quÃ¡t hÃ³a)

```text
Tá»· lá»‡ tá»•ng quÃ¡t hÃ³a (success rate): 31/50 = 62.0%
Thá»i gian Ä‘Ã¡nh giÃ¡: 12.3 ms
```

---

## Ghi chÃº há»c thuáº­t

- Q-Learning trong dá»± Ã¡n cÃ³ **workflow há»—n há»£p** khi giáº£i 1 instance (`--algo qlearning`): dá»«ng ngay khi tÃ¬m tháº¥y lá»i giáº£i Ä‘áº§u tiÃªn. Äá»ƒ Ä‘Ã¡nh giÃ¡ há»c thuáº­t nghiÃªm tÃºc, dÃ¹ng pipeline `train â†’ eval`.
- MCTS dÃ¹ng heuristic prior cá»‘ Ä‘á»‹nh (khÃ´ng há»c tá»« dá»¯ liá»‡u) â†’ Ä‘Ã¢y lÃ  **heuristic planning**, khÃ´ng pháº£i AlphaZero.
- Reward shaping hiá»‡n táº¡i lÃ  **progress-based** (khÃ´ng pháº£i potential-based chuáº©n `Î³Î¦(s') âˆ’ Î¦(s)`) â†’ khÃ´ng Ä‘áº£m báº£o báº£o toÃ n chÃ­nh sÃ¡ch tá»‘i Æ°u vá» máº·t lÃ½ thuyáº¿t.
- Äá»ƒ má»Ÿ rá»™ng sang **DQN** hoáº·c **AlphaZero tháº­t sá»±**, cáº§n thÃªm neural network xáº¥p xá»‰ Q-function hoáº·c policy/value network.

